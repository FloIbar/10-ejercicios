/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.videojuegorpg.model;

/**
 *
 * @author Santo Tomas
 */
public class ArqueroElfo extends PersonajeRPG{
    private double precisionporcentaje;

    public ArqueroElfo() {
    }

    public ArqueroElfo(double precisionporcentaje, String nombre, int puntosVida, int nivel) {
        super(nombre, puntosVida, nivel);
        this.precisionporcentaje = precisionporcentaje;
    }

    public double getPrecisionporcentaje() {
        return precisionporcentaje;
    }

    public void setPrecisionporcentaje(double precisionporcentaje) {
        this.precisionporcentaje = precisionporcentaje;
    }

    @Override
    public String toString() {
        return "ArqueroElfo{" + "precisionporcentaje=" + precisionporcentaje + '}';
    }
    
    //MP padre

    @Override
    public void atacar() {
        super.atacar(); 
    }
    
    //MP
    public void ejecutarHabilidadEspecial(){}
    public void tiempoEnfriamientoTurnos(){}
}
