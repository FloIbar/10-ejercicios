/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.videojuegorpg.model;

/**
 *
 * @author Santo Tomas
 */
public abstract class PersonajeRPG implements ILanzadorHabilidades{
    private String nombre;
    private int puntosVida;
    private int nivel;

    public PersonajeRPG() {
    }

    public PersonajeRPG(String nombre, int puntosVida, int nivel) {
        this.nombre = nombre;
        this.puntosVida = puntosVida;
        this.nivel = nivel;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPuntosVida() {
        return puntosVida;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPuntosVida(int puntosVida) {
        this.puntosVida = puntosVida;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        return "PersonajeRPG{" + "nombre=" + nombre + ", puntosVida=" + puntosVida + ", nivel=" + nivel + '}';
    }
    
    //MP
    
    public void atacar(){}
    public int recibirDanio(){
        return 12;
    }    
   
}
