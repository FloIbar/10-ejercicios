/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaaerolinea.model;

/**
 *
 * @author Santo Tomas
 */
public abstract class AsientoVuelo implements ICheckInOnline {
    private String codigoAsiento;
    private double precioTarifa;
    private boolean reservado;

    public AsientoVuelo() {
    }

    public AsientoVuelo(String codigoAsiento, double precioTarifa, boolean reservado) {
        this.codigoAsiento = codigoAsiento;
        this.precioTarifa = precioTarifa;
        this.reservado = reservado;
    }

    public String getCodigoAsiento() {
        return codigoAsiento;
    }

    public double getPrecioTarifa() {
        return precioTarifa;
    }

    public boolean isReservado() {
        return reservado;
    }

    public void setCodigoAsiento(String codigoAsiento) {
        this.codigoAsiento = codigoAsiento;
    }

    public void setPrecioTarifa(double precioTarifa) {
        this.precioTarifa = precioTarifa;
    }

    public void setReservado(boolean reservado) {
        this.reservado = reservado;
    }

    @Override
    public String toString() {
        return "AsientoVuelo{" + "codigoAsiento=" + codigoAsiento + ", precioTarifa=" + precioTarifa + ", reservado=" + reservado + '}';
    }
    
    //MP
    public void reservarAseinto(){}
    public void calcularEquipajePermitido(){}
}
