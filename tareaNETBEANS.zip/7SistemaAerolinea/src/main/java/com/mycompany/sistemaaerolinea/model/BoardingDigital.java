/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaaerolinea.model;

/**
 *
 * @author Santo Tomas
 */
public class BoardingDigital extends AsientoVuelo{
    private String codigoQR;

    public BoardingDigital() {
    }

    public BoardingDigital(String codigoQR, String codigoAsiento, double precioTarifa, boolean reservado) {
        super(codigoAsiento, precioTarifa, reservado);
        this.codigoQR = codigoQR;
    }

    public String getCodigoQR() {
        return codigoQR;
    }

    public void setCodigoQR(String codigoQR) {
        this.codigoQR = codigoQR;
    }

    @Override
    public String toString() {
        return "BoardingDigital{" + "codigoQR=" + codigoQR + '}';
    }
    
    //MP padre

    @Override
    public void calcularEquipajePermitido() {
        super.calcularEquipajePermitido(); 
    }
    
    //MP
    public void emitirBoardingPass(){}
    public String validarPasaporte(){
            return "num";
    }

    @Override
    public void emtirBoardingPass() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
