/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaaerolinea.model;

/**
 *
 * @author Santo Tomas
 */
public class AsientoBusiness extends AsientoVuelo{
    private boolean accesoLounge;
    private CabinaPrivada suiteCabina;

    public AsientoBusiness() {
    }

    public AsientoBusiness(boolean accesoLounge, CabinaPrivada suiteCabina, String codigoAsiento, double precioTarifa, boolean reservado) {
        super(codigoAsiento, precioTarifa, reservado);
        this.accesoLounge = accesoLounge;
        this.suiteCabina = suiteCabina;
    }

    public boolean isAccesoLounge() {
        return accesoLounge;
    }

    public CabinaPrivada getSuiteCabina() {
        return suiteCabina;
    }

    public void setAccesoLounge(boolean accesoLounge) {
        this.accesoLounge = accesoLounge;
    }

    public void setSuiteCabina(CabinaPrivada suiteCabina) {
        this.suiteCabina = suiteCabina;
    }

    @Override
    public String toString() {
        return "AsientoBusiness{" + "accesoLounge=" + accesoLounge + ", suiteCabina=" + suiteCabina + '}';
    }
    
    //MP padre

    @Override
    public void calcularEquipajePermitido() {
        super.calcularEquipajePermitido(); 
    }
    
    //MP
    public void solicitarChampagne(){}

    @Override
    public void emtirBoardingPass() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String validarPasaporte() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
