/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaaerolinea.model;

/**
 *
 * @author Santo Tomas
 */
public class CabinaPrivada {
    private int numPantallaHD;
    private boolean asientoReclinable180;

    public CabinaPrivada() {
    }

    public CabinaPrivada(int numPantallaHD, boolean asientoReclinable180) {
        this.numPantallaHD = numPantallaHD;
        this.asientoReclinable180 = asientoReclinable180;
    }

    public int getNumPantallaHD() {
        return numPantallaHD;
    }

    public boolean isAsientoReclinable180() {
        return asientoReclinable180;
    }

    public void setNumPantallaHD(int numPantallaHD) {
        this.numPantallaHD = numPantallaHD;
    }

    public void setAsientoReclinable180(boolean asientoReclinable180) {
        this.asientoReclinable180 = asientoReclinable180;
    }

    @Override
    public String toString() {
        return "CabinaPrivada{" + "numPantallaHD=" + numPantallaHD + ", asientoReclinable180=" + asientoReclinable180 + '}';
    }
    
    //MP
    public void activarMasaje(){}
}
