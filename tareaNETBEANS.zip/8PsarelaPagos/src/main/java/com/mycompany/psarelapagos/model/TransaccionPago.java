/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.psarelapagos.model;

/**
 *
 * @author Santo Tomas
 */
public abstract class TransaccionPago implements IVerificableBlockchain{
    private String idTransaccion;
    private double montoUSD;
    private boolean completado;

    public TransaccionPago() {
    }

    public TransaccionPago(String idTransaccion, double montoUSD, boolean completado) {
        this.idTransaccion = idTransaccion;
        this.montoUSD = montoUSD;
        this.completado = completado;
    }

    public String getIdTransaccion() {
        return idTransaccion;
    }

    public double getMontoUSD() {
        return montoUSD;
    }

    public boolean isCompletado() {
        return completado;
    }

    public void setIdTransaccion(String idTransaccion) {
        this.idTransaccion = idTransaccion;
    }

    public void setMontoUSD(double montoUSD) {
        this.montoUSD = montoUSD;
    }

    public void setCompletado(boolean completado) {
        this.completado = completado;
    }

    @Override
    public String toString() {
        return "TransaccionPago{" + "idTransaccion=" + idTransaccion + ", montoUSD=" + montoUSD + ", completado=" + completado + '}';
    }
    
    //MP
    public void procesarPago(){}
    public void generarComprobante(){}
}
