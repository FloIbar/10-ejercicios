/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.psarelapagos.model;

/**
 *
 * @author Santo Tomas
 */
public class EncriptadorRSA {
    private int longitudLlave;
    private String tokenSeguridad;

    public EncriptadorRSA() {
    }

    public EncriptadorRSA(int longitudLlave, String tokenSeguridad) {
        this.longitudLlave = longitudLlave;
        this.tokenSeguridad = tokenSeguridad;
    }

    public int getLongitudLlave() {
        return longitudLlave;
    }

    public String getTokenSeguridad() {
        return tokenSeguridad;
    }

    public void setLongitudLlave(int longitudLlave) {
        this.longitudLlave = longitudLlave;
    }

    public void setTokenSeguridad(String tokenSeguridad) {
        this.tokenSeguridad = tokenSeguridad;
    }

    @Override
    public String toString() {
        return "EncriptadorRSA{" + "longitudLlave=" + longitudLlave + ", tokenSeguridad=" + tokenSeguridad + '}';
    }
    
    //MP
    public String encriptarDatos(){
        return"Encriptando";
    }
    

            
}
