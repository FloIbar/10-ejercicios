/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cocinayrestaurante.model;

/**
 *
 * @author Flo
 */
public class PedidoDelivery extends PlatilloMenu{
    private String direccionEntrega;

    public PedidoDelivery() {
    }

    public PedidoDelivery(String direccionEntrega, String idPlato, String nombre, double precioBase) {
        super(idPlato, nombre, precioBase);
        this.direccionEntrega = direccionEntrega;
    }

    public String getDireccionEntrega() {
        return direccionEntrega;
    }

    public void setDireccionEntrega(String direccionEntrega) {
        this.direccionEntrega = direccionEntrega;
    }

    @Override
    public String toString() {
        return "PedidoDelivery{" + "direccionEntrega=" + direccionEntrega + '}';
    }
    
    //MP Padre

    @Override
    public void calcularPrecioFinal() {
        super.calcularPrecioFinal(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    //MP
    public void sellarEmpaque(){}
    public void tiempoConservacionMin(){}
    
}
