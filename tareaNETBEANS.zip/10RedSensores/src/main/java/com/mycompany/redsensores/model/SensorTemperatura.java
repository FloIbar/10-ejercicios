/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.redsensores.model;

/**
 *
 * @author Santo Tomas
 */
public class SensorTemperatura extends SensorIndustrial {
    private double gradosCelsius;

    public SensorTemperatura() {
    }

    public SensorTemperatura(double gradosCelsius, String idSensor, String ubicacionArea, boolean activo) {
        super(idSensor, ubicacionArea, activo);
        this.gradosCelsius = gradosCelsius;
    }

    public double getGradosCelsius() {
        return gradosCelsius;
    }

    public void setGradosCelsius(double gradosCelsius) {
        this.gradosCelsius = gradosCelsius;
    }

    @Override
    public String toString() {
        return "SensorTemperatura{" + "gradosCelsius=" + gradosCelsius + '}';
    }
    
    //MP padre

    @Override
    public void tomarLectura() {
        super.tomarLectura(); 
    }
    
    //MP
    public void dispararSirenaEmergencia(){}
    public void enviarNotificacionMQTT(){}
    
}
