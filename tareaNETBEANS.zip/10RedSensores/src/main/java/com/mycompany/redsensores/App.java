/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.redsensores;

/**
 *
 * @author Santo Tomas
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
