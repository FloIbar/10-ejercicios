/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.redsensores.model;

/**
 *
 * @author Santo Tomas
 */
public class SensorPresion extends SensorIndustrial {
    private double presionPSI;
    private CalibradorDigital dispositivoCalibrador;

    public SensorPresion() {
    }

    public SensorPresion(double presionPSI, CalibradorDigital dispositivoCalibrador, String idSensor, String ubicacionArea, boolean activo) {
        super(idSensor, ubicacionArea, activo);
        this.presionPSI = presionPSI;
        this.dispositivoCalibrador = dispositivoCalibrador;
    }

    public double getPresionPSI() {
        return presionPSI;
    }

    public CalibradorDigital getDispositivoCalibrador() {
        return dispositivoCalibrador;
    }

    public void setPresionPSI(double presionPSI) {
        this.presionPSI = presionPSI;
    }

    public void setDispositivoCalibrador(CalibradorDigital dispositivoCalibrador) {
        this.dispositivoCalibrador = dispositivoCalibrador;
    }

    @Override
    public String toString() {
        return "SensorPresion{" + "presionPSI=" + presionPSI + ", dispositivoCalibrador=" + dispositivoCalibrador + '}';
    }
    
    //MP padre

    @Override
    public void tomarLectura() {
        super.tomarLectura(); 
    }
    
    //MP
    public void medirDeltaPresion(){}

    @Override
    public void dispararSirenaEmergencia() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void enviarNotificacionMQTT() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
