/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaatencionmedica.model;

/**
 *
 * @author Flo
 */
public abstract class AtencionMedica implements IFacturableDigital {
  private String codigoAtencion;
  private double costoBase;

    public AtencionMedica() {
    }

    public AtencionMedica(String codigoAtencion, double costoBase) {
        this.codigoAtencion = codigoAtencion;
        this.costoBase = costoBase;
    }

    public String getCodigoAtencion() {
        return codigoAtencion;
    }

    public double getCostoBase() {
        return costoBase;
    }

    public void setCodigoAtencion(String codigoAtencion) {
        this.codigoAtencion = codigoAtencion;
    }

    public void setCostoBase(double costoBase) {
        this.costoBase = costoBase;
    }

    @Override
    public String toString() {
        return "AtencionMedica{" + "codigoAtencion=" + codigoAtencion + ", costoBase=" + costoBase + '}';
    }
  
  //MP
    
    public void calcularCostoTotal(){}
    
    public String registrarDiagnostico(){
        return"Hola";
    }
}
