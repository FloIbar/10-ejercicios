/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemaatencionmedica.model;

/**
 *
 * @author Flo
 */
public class Telemedicina extends AtencionMedica{
    private String plataformaVideo;

    public Telemedicina() {
    }

    public Telemedicina(String plataformaVideo, String codigoAtencion, double costoBase) {
        super(codigoAtencion, costoBase);
        this.plataformaVideo = plataformaVideo;
    }

    public String getPlataformaVideo() {
        return plataformaVideo;
    }

    public void setPlataformaVideo(String plataformaVideo) {
        this.plataformaVideo = plataformaVideo;
    }

    @Override
    public String toString() {
        return "Telemedicina{" + "plataformaVideo=" + plataformaVideo + '}';
    }
    
    //mp padre

    @Override
    public void calcularCostoTotal() {
        super.calcularCostoTotal(); 
    }
    
    //MP
    public void generarFacturaXML(){}
    
    public String enviarPorCorreo(){
        return"Hola";
    }

    @Override
    public void generarfacturaXML() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
