/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotel.model;

/**
 *
 * @author Flo
 */
public class SuiteTematica extends HabitacionHotel{
    private String tematicaDecoracion;

    public SuiteTematica() {
    }

    public SuiteTematica(String tematicaDecoracion, int numeroHabitacion, double precioNocheBase, boolean ocupada) {
        super(numeroHabitacion, precioNocheBase, ocupada);
        this.tematicaDecoracion = tematicaDecoracion;
    }

    public String getTematicaDecoracion() {
        return tematicaDecoracion;
    }

    public void setTematicaDecoracion(String tematicaDecoracion) {
        this.tematicaDecoracion = tematicaDecoracion;
    }

    @Override
    public String toString() {
        return "SuiteTematica{" + "tematicaDecoracion=" + tematicaDecoracion + '}';
    }
    
    //metodos Personalizados padre

    @Override
    public int calcularCostosEstadia() {
        return 3;
    }
    
    //MP
    public void iniciarCicloDesinfeccion(){
        System.out.println("Iniciando");
    }    
    public void obtenerReporteSeguridad(){
        System.out.println("Obteniendo");
    }
   
    }
           
    

