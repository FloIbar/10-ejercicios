/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotel.model;

/**
 *
 * @author Flo
 */
public class HabitacionEstandar extends HabitacionHotel {
    private int camasSupletorias;

    public HabitacionEstandar() {
    }

    public HabitacionEstandar(int camasSupletorias, int numeroHabitacion, double precioNocheBase, boolean ocupada) {
        super(numeroHabitacion, precioNocheBase, ocupada);
        this.camasSupletorias = camasSupletorias;
    }

    public int getCamasSupletorias() {
        return camasSupletorias;
    }

    public void setCamasSupletorias(int camasSupletorias) {
        this.camasSupletorias = camasSupletorias;
    }

    @Override
    public String toString() {
        return "HabitacionEstandar{" + "camasSupletorias=" + camasSupletorias + '}';
    }

    //Metodos personalizados padre
    
    @Override
    public int calcularCostosEstadia() {
        return 2;
    }
    
    //Metodos Personalizados
    
    public void solicitarToallasExtra(){
        System.out.println("solcitando");
    }

    @Override
    public void iniciarCicloDesinfeccion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void obtenerReporteSeguridad() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
