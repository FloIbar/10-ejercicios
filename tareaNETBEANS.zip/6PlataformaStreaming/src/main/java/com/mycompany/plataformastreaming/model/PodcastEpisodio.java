/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.plataformastreaming.model;

/**
 *
 * @author Santo Tomas
 */
public class PodcastEpisodio extends ContenidoMedia{
    private int numEpisodio;

    public PodcastEpisodio() {
    }

    public PodcastEpisodio(int numEpisodio, String idMedia, String titulo, int duracionSeg) {
        super(idMedia, titulo, duracionSeg);
        this.numEpisodio = numEpisodio;
    }

    public int getNumEpisodio() {
        return numEpisodio;
    }

    public void setNumEpisodio(int numEpisodio) {
        this.numEpisodio = numEpisodio;
    }

    @Override
    public String toString() {
        return "PodcastEpisodio{" + "numEpisodio=" + numEpisodio + '}';
    }
    
    //MP
    
    public void guardarEnCache(){}
    public void verificarEspacioDisk(){}
}
