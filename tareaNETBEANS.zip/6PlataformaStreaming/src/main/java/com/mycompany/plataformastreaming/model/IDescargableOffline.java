/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.plataformastreaming.model;

/**
 *
 * @author Santo Tomas
 */
public interface IDescargableOffline {
    void guardarEnCache();
    void verificarEspacioDisk();
    
}
