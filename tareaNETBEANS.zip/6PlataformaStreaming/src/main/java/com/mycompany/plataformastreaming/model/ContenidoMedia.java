/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.plataformastreaming.model;

/**
 *
 * @author Santo Tomas
 */
public abstract class ContenidoMedia {
    private String idMedia;
    private String titulo;
    private int duracionSeg;

    public ContenidoMedia() {
    }

    public ContenidoMedia(String idMedia, String titulo, int duracionSeg) {
        this.idMedia = idMedia;
        this.titulo = titulo;
        this.duracionSeg = duracionSeg;
    }

    public String getIdMedia() {
        return idMedia;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getDuracionSeg() {
        return duracionSeg;
    }

    public void setIdMedia(String idMedia) {
        this.idMedia = idMedia;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDuracionSeg(int duracionSeg) {
        this.duracionSeg = duracionSeg;
    }

    @Override
    public String toString() {
        return "ContenidoMedia{" + "idMedia=" + idMedia + ", titulo=" + titulo + ", duracionSeg=" + duracionSeg + '}';
    }
    
    //MP
    
    public void reproducir(){}
    
    public void pausar(){}
}
