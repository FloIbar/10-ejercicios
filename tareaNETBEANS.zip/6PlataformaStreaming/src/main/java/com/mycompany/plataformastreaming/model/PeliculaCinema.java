/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.plataformastreaming.model;

/**
 *
 * @author Santo Tomas
 */
public class PeliculaCinema extends ContenidoMedia{
    private String director;

    public PeliculaCinema() {
    }

    public PeliculaCinema(String director, String idMedia, String titulo, int duracionSeg) {
        super(idMedia, titulo, duracionSeg);
        this.director = director;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    @Override
    public String toString() {
        return "PeliculaCinema{" + "director=" + director + '}';
    }
    
    //MP 
    
    public void mostrarTrailer(){}
}
