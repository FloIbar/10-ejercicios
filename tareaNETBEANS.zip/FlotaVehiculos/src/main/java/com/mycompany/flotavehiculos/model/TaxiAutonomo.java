/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.flotavehiculos.model;

/**
 *
 * @author Flo
 */
public class TaxiAutonomo extends VehiculoAutonomo {
    private double tarifaPorKm;
    private BateriaLitio packBaterias;

    public TaxiAutonomo() {
    }

    public TaxiAutonomo(double tarifaPorKm, BateriaLitio packBaterias, String vin, double velocidadMax, boolean enRuta) {
        super(vin, velocidadMax, enRuta);
        this.tarifaPorKm = tarifaPorKm;
        this.packBaterias = packBaterias;
    }

    public double getTarifaPorKm() {
        return tarifaPorKm;
    }

    public BateriaLitio getPackBaterias() {
        return packBaterias;
    }

    public void setTarifaPorKm(double tarifaPorKm) {
        this.tarifaPorKm = tarifaPorKm;
    }

    public void setPackBaterias(BateriaLitio packBaterias) {
        this.packBaterias = packBaterias;
    }

    @Override
    public String toString() {
        return "TaxiAutonomo{" + "tarifaPorKm=" + tarifaPorKm + ", packBaterias=" + packBaterias + '}';
    }
    
    //MP
    
    public void solicitarRecargaRapida(){}

    @Override
    public void obtenerCoordenadas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void transmitirTelemetria() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
