/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.flotavehiculos.model;

/**
 *
 * @author Flo
 */
public class BusExpreso extends VehiculoAutonomo {
    private int capacidadPasajeros;

    public BusExpreso() {
    }

    public BusExpreso(int capacidadPasajeros, String vin, double velocidadMax, boolean enRuta) {
        super(vin, velocidadMax, enRuta);
        this.capacidadPasajeros = capacidadPasajeros;
    }

    public int getCapacidadPasajeros() {
        return capacidadPasajeros;
    }

    public void setCapacidadPasajeros(int capacidadPasajeros) {
        this.capacidadPasajeros = capacidadPasajeros;
    }

    @Override
    public String toString() {
        return "BusExpreso{" + "capacidadPasajeros=" + capacidadPasajeros + '}';
    }
    
    //MP
    
    public void anunciarSiguienteParada(){}

    @Override
    public void obtenerCoordenadas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void transmitirTelemetria() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
