/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bibliotecadigital.model;

/**
 *
 * @author Flo
 */
public class RevistaAcademica extends RecursoBiblioteca {
    private int numeroEdicion;
    private String doiLicencia;

    public RevistaAcademica() {
    }

    public RevistaAcademica(int numeroEdicion, String doiLicencia, String id, String titulo, boolean disponible) {
        super(id, titulo, disponible);
        this.numeroEdicion = numeroEdicion;
        this.doiLicencia = doiLicencia;
    }

    public int getNumeroEdicion() {
        return numeroEdicion;
    }

    public String getDoiLicencia() {
        return doiLicencia;
    }

    public void setNumeroEdicion(int numeroEdicion) {
        this.numeroEdicion = numeroEdicion;
    }

    public void setDoiLicencia(String doiLicencia) {
        this.doiLicencia = doiLicencia;
    }

    @Override
    public String toString() {
        return "RevistaAcademica{" + "numeroEdicion=" + numeroEdicion + ", doiLicencia=" + doiLicencia + '}';
    }
    
    //mp
    
    public void descargar(){
        System.out.println("descargando...");
    }

    @Override
    public void descarga() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
